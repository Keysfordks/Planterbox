import Link from 'next/link';
import { Button, Card } from 'antd';
import { CheckCircleOutlined, SafetyOutlined, ThunderboltOutlined, ArrowRightOutlined } from '@ant-design/icons';
import { auth } from './api/auth/[...nextauth]/route';
import Navbar from '../components/navbar';
import styles from '../styles/home.module.css';

export default async function HomePage() {

  const features = [
    {
      icon: <CheckCircleOutlined />,
      title: 'Easy to Use',
      description: 'Simple and intuitive interface for everyone.',
    },
    {
      icon: <SafetyOutlined />,
      title: 'Secure',
      description: 'Your data is protected with OAuth authentication.',
    },
    {
      icon: <ThunderboltOutlined />,
      title: 'Fast',
      description: 'Lightning-fast performance and real-time updates.',
    },
  ];

  return (
    <div className={styles.container}>
      <Navbar />
      <main className={styles.main}>
        <div className={styles.hero}>
          <h1 className={styles.heroTitle}>
            Welcome to <span className={styles.heroTitleAccent}>PlanterBox</span>
          </h1>
          <p className={styles.heroDescription}>
            Your personal dashboard for managing projects, tracking progress, and staying organized.
          </p>
          
          <div className={styles.ctaContainer}>
              <Link href="/dashboard">
                <Button type="primary" size="large" icon={<ArrowRightOutlined />} className={styles.ctaButton}>
                  Go to Dashboard
                </Button>
              </Link>
          </div>
        </div>
      </main>
    </div>
  );
}